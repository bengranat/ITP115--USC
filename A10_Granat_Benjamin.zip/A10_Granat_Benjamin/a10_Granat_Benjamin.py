# Ben Granat, bgranat@usc.edu
# ITP 115, Fall 2022
# Section: Goomba
# Assignment 10
# Description:
# Program manages a menu. User can add, update, show price, delete, and show menu.

def displayChoices():
    v = """Manage the Menu
    a) Add a menu item
    b) Update the price
    c) Show the price
    d) Delete a menu item
    e) Show the menu
    x) Exit
 """
    print(v)

def isFloat(num_str):
    num_str = num_str.strip().replace(".", "", 1)
    if num_str.isdigit():
        return True
    else:
        return False

def addItem(menu_dict):
    food_input = input("Enter a food item to add: ")
    food_key = food_input.strip().title()
    if food_key in menu_dict.keys():
        print(food_key, "is already on the menu.")
    else:
        price_input = input("Enter the price: ")
        while not isFloat(price_input):
            price_input = input("Enter the price: ")
        price_value = float(price_input)
        menu_dict[food_key] = price_value
        print(food_input, "has been added to the menu.")

def updatePrice(menu_dict):
    food_input = input("Enter a food item to update: ")
    food_key = food_input.strip().title()
    if food_key in menu_dict.keys():
        print(food_key, "costs", "$" + str(menu_dict[food_key]))
        price_input = input("Enter the price: ")
        while not isFloat(price_input):
            price_input = input("Enter the price: ")
        menu_dict[food_key] = price_input
        print(food_key, "now costs", "$" + price_input)
    if food_key not in menu_dict.keys():
        print(food_key, "is not on the menu.")

def showPrice(menu_dict):
    food_input = input("Enter a food item to find: ")
    food_key = food_input.strip().title()
    if food_key in menu_dict.keys():
        print(food_key, "costs", "$" + menu_dict[food_key])
    else:
        print(food_key, "is not on the menu.")

def deleteItem(menu_dict):
    food_input = input("Enter a food item to find: ")
    food_key = food_input.strip().title()
    if food_key in menu_dict.keys():
        del menu_dict[food_key]
        print(food_key, "was deleted from the menu.")
    else:
        print(food_key, "is not on the menu")

def showMenu(menu_dict):
    for key in menu_dict:
        print(key, "costs", "$" + str(menu_dict[key]))

def main():
    menu_dict = {"Burger": 10.99, "Fries": 2.99, "Soda": 1.99}
    displayChoices()
    user_input = input("Choice: ")
    user_input = user_input.strip().lower()
    while user_input != "x":
        if user_input == "a":
            addItem(menu_dict)
            displayChoices()
            user_input = input("Choice: ")
        if user_input == "b":
            updatePrice(menu_dict)
            displayChoices()
            user_input = input("Choice: ")
        if user_input == "c":
            showPrice(menu_dict)
            displayChoices()
            user_input = input("Choice: ")
        if user_input == "d":
            deleteItem(menu_dict)
            displayChoices()
            user_input = input("Choice: ")
        if user_input == "e":
            showMenu(menu_dict)
            displayChoices()
            user_input = input("Choice: ")

main()



