"""
Ben Granat bgranat@usc.edu
ITP115, Fall 2022
Assignment 7
User will play rock-paper-scissors against the computer.
They will play a best of three.
"""

import random as rd


# Function to display rules

def displayRules():
    text = """Let's play Rock Paper Scissors. The rules of the game are:
                ROCK smashes SCISSORS
                SCISSORS cut PAPER
                PAPER covers ROCK
If both the hands are the same, it's a tie"""
    print(text)

# Function which generates user input for rock-paper-scissors

def userPlayer(options_list):
    user_input = ""
    count = 0
    user_input = str(input("Enter rock, paper, or scissors"))
    while count != 1:
        for i in range(0, 3):
            if user_input == options_list[i]:
                print("User plays:", options_list[i])
                count += 1

    return user_input

# Function which generates computer input for rock-paper-scissors

def computerPlays(options_list):
    comp_choice = rd.choice(options_list)
    print("Computer plays:", comp_choice)
    return comp_choice

# Function which checks the outcome for game of rock-paper-scissors and returns result (boolean)

def gameOutcome(comp_choice, user_input):
    result = bool
    if comp_choice == user_input:
        print("You and the computer have tied.")
    elif comp_choice == "rock" and user_input == "paper":
        print("You win!")
        result = True
        return result
    elif comp_choice == "paper" and user_input == "scissors":
        print("You win!")
        result = True
        return result
    elif comp_choice == "scissors" and user_input == "rock":
        print("You win!")
        result = True
        return result
    else:
        print("Computer wins!")
        result = False
        return result

# Main function which contains while loops for best of three games and counts user/computer wins

def main():
    user_win_count = 0
    computer_win_count = 0
    options_list = ["rock", "paper", "scissors"]
    displayRules()
    while user_win_count != 2 and computer_win_count != 2:
        user_input = userPlayer(options_list)
        comp_choice = computerPlays(options_list)
        game_outcome = gameOutcome(comp_choice, user_input)
        if game_outcome is True:
            user_win_count += 1
        elif game_outcome is False:
            computer_win_count += 1
    print("The computer won", computer_win_count, "games.")
    print("User won", user_win_count, "games.")

main()



