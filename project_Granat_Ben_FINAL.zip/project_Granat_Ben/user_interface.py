# Benjamin Granat, bgranat@usc.edu
# ITP 115, Fall 2022
# Section: Goomba
# Final Project
# user_interface.py
# Description:
# This file houses functions that will interface with the user.
# The below functions will be referenced in main file.

# Import helper file for function reference.
import helper

# Function displays menu dictionary
def displayMenu(menu_dict):
    for key, value in menu_dict.items():
        print(key + " -> " + value)

# Function to check if user choice is in menu dictionary
def getUserChoice(menu_dict):
    key_list = menu_dict.keys()
    user_input = input("Choice: ")
    user_input = user_input.strip().upper()
    while user_input not in key_list:
        user_input = input("Choice: ")
        user_input = user_input.strip().upper()
    return user_input

# Function to display the total number of coasters
def displayNumCoasters(coasters_list):
    count = 0
    for i in coasters_list:
        count += 1
    print("The total number of coasters is " + str(count) + ".")

# Function to display the total number of operating coasters
def displayNumOperatingCoasters(coasters_list):
    count = 0
    for i in coasters_list:
        coaster_status = i['status']
        if coaster_status == 'operating':
            count += 1
    print("The total number of operating coasters is " + str(count) + ".")

# Function to display the individual coaster's dictionary
def displayCoaster(coaster_dict):
    coaster_name = coaster_dict['name']
    coaster_park = coaster_dict['park']
    print(coaster_name + " " + "[" + coaster_park + "]")
    coaster_speed = coaster_dict['speed'] + "mph"
    if coaster_speed != "mph":
        print(" " + "Speed = " + coaster_speed)
    coaster_height = coaster_dict['height'] + "ft"
    if coaster_height != "ft":
        print(" " + "Height = " + coaster_height)
    coaster_length = coaster_dict['length'] + "ft"
    if coaster_length != "ft":
        print(" " + "Length = " + coaster_length)
    coaster_status = coaster_dict['status']
    print(" " + "Status is " + coaster_status)


# Function to display the fastest coaster
def displayFastestCoaster(coasters_list):
    fastest_coaster = helper.getFastestCoaster(coasters_list)
    displayCoaster(fastest_coaster)


# Function to display all parks in the list of coaster dictionaries
def displayAllParks(coasters_list):
    parks_list = helper.getParks(coasters_list)
    count = 0
    print("Amusement parks in alphabetical order: ")
    for i in parks_list:
        print(i)
        count += 1
    print("There are " + str(count) + " unique parks.")

# Function to display all coasters in a given park
# User will search for a park
# Function checks if user input is in coasters list
def displayCoastersinPark(coasters_list):
    user_input = input("Enter a park: ")
    user_input = user_input.strip().lower()
    count = 0
    park_coaster_list = []
    for i in coasters_list:
        park_key = i['park']
        park_key = park_key.lower()
        if user_input in park_key:
            count += 1
            park_coaster_list.append(i)
    if count == 0:
        print("No coasters in " + user_input)
    for i in park_coaster_list:
        displayCoaster(i)
    print(user_input + " has " + str(count) + " coasters.")

# Function to find all coasters based on search term
# Output is all coaster dictionaries wih user input as its name
def findCoasters(coasters_list):
    user_input = input("Enter a search phrase: ")
    user_input = user_input.strip().lower()
    count = 0
    for i in coasters_list:
        name_key = i['name']
        name_key = name_key.lower()
        if user_input in name_key:
            count += 1
            displayCoaster(i)
    print("Found " + str(count) + " that contain " + user_input)
    if count == 0:
        print("No coasters contain " + user_input)


