# Benjamin Granat, bgranat@usc.edu
# ITP 115, Fall 2022
# Section: Goomba
# Final Project
# helper.py
# Description:
# File houses several functions that will be called in other Python files.
# Output from below functions will be used in other files.

# Function to create coasters from file
# Reads header row as keys, the rest of the lines as values
# Output is a list of coaster dictionaries
def createCoastersFromFile(file_name):
    dict_list = []
    roller_coasters = open(file_name, "r")
    header_row = roller_coasters.readline()
    key_list = header_row.split(",")
    key_list[9] = key_list[9][:6]
    for line in roller_coasters:
        coaster_dict = {}
        line = line.strip()
        coaster_data = line.split(",")
        coaster_data[9] = coaster_data[9][7:]
        for key in key_list:
            index = key_list.index(key)
            coaster_dict[key] = coaster_data[index]
        dict_list.append(coaster_dict)
    roller_coasters.close()
    return dict_list

# Function to get all parks in list of coaster dictionaries
# Output is a list of parks
def getParks(coasters_list):
    parks_list = []
    for i in coasters_list:
        if i['park'] not in parks_list:
            parks_list.append(i['park'])
    parks_list.sort()
    return parks_list

# Function to get the fastest coaster out of a list of coaster dictionaries
# Output is the dictionary associated with the fastest coaster
def getFastestCoaster(coasters_list):
    for i in coasters_list:
        coaster_speed = i['speed']
        if coaster_speed.isdigit():
            coaster_speed = int(coaster_speed)
            count = 0
            for g in coasters_list:
                compare_variable = g['speed']
                if compare_variable.isdigit():
                    compare_variable = int(compare_variable)
                    if coaster_speed < compare_variable:
                        count += 1
        if count == 0:
            return i
