# Benjamin Granat, bgranat@usc.edu
# ITP 115, Fall 2022
# Section: Goomba
# Final Project
# main_Granat_Ben.py
# Description:
# This file houses the getMenuDict and main functions.

# Imports other two files in directory
import helper
import user_interface


# Creates menu dictionary
def getMenuDict():
    key_list = ["A", "B", "C", "D", "E", "F", "Q"]
    value_list = ["Number of coasters", "Number of operating coasters", "Fastest coaster", "Amusement parks",
                  "Coasters in a park", "Find coasters", "Quit"]
    menu_dict = {}
    for i in range(0, len(key_list)):
        menu_dict[key_list[i]] = value_list[i]
    return menu_dict

# Main function
def main():
    print("Roller Coasters")
    file_name = "roller_coasters.csv"
    coasters_list = helper.createCoastersFromFile(file_name)
    menu_dict = getMenuDict()
    user_interface.displayMenu(menu_dict)
    user_input = user_interface.getUserChoice(menu_dict)
    # Branching statements for cases of user input
    while user_input != "Q":
        if user_input == "A":
            # Number of coasters
            user_interface.displayNumCoasters(coasters_list)
            user_interface.displayMenu(menu_dict)
            user_input = user_interface.getUserChoice(menu_dict)
        elif user_input == "B":
            # Number of operating coasters
            user_interface.displayNumOperatingCoasters(coasters_list)
            user_interface.displayMenu(menu_dict)
            user_input = user_interface.getUserChoice(menu_dict)
        elif user_input == "C":
            # Fastest coaster
            user_interface.displayFastestCoaster(coasters_list)
            user_interface.displayMenu(menu_dict)
            user_input = user_interface.getUserChoice(menu_dict)
        elif user_input == "D":
            # Display all parks
            user_interface.displayAllParks(coasters_list)
            user_interface.displayMenu(menu_dict)
            user_input = user_interface.getUserChoice(menu_dict)
        elif user_input == "E":
            # Display all coasters in searched park
            user_interface.displayCoastersinPark(coasters_list)
            user_interface.displayMenu(menu_dict)
            user_input = user_interface.getUserChoice(menu_dict)
        elif user_input == "F":
            # Find all coasters associated with search term
            user_interface.findCoasters(coasters_list)
            user_interface.displayMenu(menu_dict)
            user_input = user_interface.getUserChoice(menu_dict)
        else:
            user_interface.displayMenu(menu_dict)
            user_input = user_interface.getUserChoice(menu_dict)

main()

