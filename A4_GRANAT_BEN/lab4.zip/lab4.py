n = 10
for i in range(0,n):
    y = print('*' * (2 * i + 1))




