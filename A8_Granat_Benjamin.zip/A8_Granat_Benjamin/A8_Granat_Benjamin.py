"""
Ben Granat bgranat@usc.edu
ITP115, Fall 2022
Assignment 8
Program generates random N-digit code
User tries to guess digits in the cods
Incorrect answers will prompt a hint
User can try as many times as they like
"""

import random as rd


def isSingleDigit(user_inp):
    if user_inp.isdigit() and len(user_inp) == 1:
        return True
    else:
        return False


def generateCodeList(size):
    code_arr = []
    for i in range(size):
        x = rd.randint(0,9)
        code_arr.append(x)
    return code_arr


def getUserList(size):
    print("The number of digits in the code is:", size)
    user_arr = []
    index_count = 0
    for i in range(0, size):
        user_inp = input('Enter a digit at index ' + str(index_count) + ': ')
        while isSingleDigit(user_inp) == False:
            user_inp = input('Enter a digit at index ' + str(index_count) + ': ')
        user_arr.append(int(user_inp))
        index_count += 1
    print("Your guess is:", user_arr)
    return user_arr


def printHints(code_arr, user_arr):
    print("Generating hints...")
    count_hints = 0
    for i in range(0, len(user_arr)):
        if code_arr.count(user_arr[i]) >= 1:
            count_hints += 1
            print(user_arr[i], "occurs", code_arr.count(user_arr[i]), "time(s) in the code.")
    for i in range(0, len(user_arr)):
        if user_arr[i] == code_arr[i]:
            count_hints += 1
            print(user_arr[i], "is in the correct position.")
    if count_hints == 0:
        print("No correct digits.")


def main():
    size = int(input("What is the size of your code?:"))
    code_arr = generateCodeList(size)
    user_arr = getUserList(size)
    guess_count = 0
    while code_arr != user_arr:
        printHints(code_arr, user_arr)
        guess_count += 1
        user_arr = getUserList(size)
    print("You cracked the code in", guess_count, "guesses.")


main()






